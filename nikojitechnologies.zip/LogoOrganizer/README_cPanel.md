# Nikoji Technologies - cPanel Deployment Guide

This guide outlines the steps to deploy the Nikoji Technologies website on a cPanel hosting environment. Follow these instructions carefully to ensure a successful deployment.

## Prerequisites

Before you begin, make sure you have:

1. A cPanel hosting account with Python application support
2. FTP access to your hosting account (FTP credentials)
3. SSH access (if available, but not required)
4. The Nikoji Technologies project files ready for deployment

## Preparation

1. **Backup your project**: Create a backup of your local development project
2. **Collect static files**: Run the following command locally before uploading:
   ```bash
   python manage.py collectstatic
   ```
3. **Export your database schema**: If you have local data you want to preserve:
   ```bash
   python manage.py dumpdata > data_backup.json
   ```

## Step 1: Setting up Python Application in cPanel

1. Log in to your cPanel account
2. In the **Software** section, click on **Setup Python App**
3. Click **Create Application** and fill in the following details:
   - **Python Version**: Select Python 3.8 or newer
   - **Application Root**: Public path where your Django app will be installed (e.g., `nikoji`)
   - **Application URL**: Your domain or subdomain (e.g., `https://www.nikojitechnologies.com` or `https://nikoji.yourdomain.com`)
   - **Application Entry Point**: `/nikoji_project/wsgi.py` (path to your WSGI file)
   - **Application Startup File**: `passenger_wsgi.py` (this will be created automatically)
4. Click **Create** to set up the Python application environment

## Step 2: Upload Project Files

### Using FTP Client (FileZilla, Cyberduck, etc.)

1. Connect to your server using FTP credentials
2. Navigate to the application root directory you specified when setting up the Python app
3. Upload all project files to this directory, maintaining the correct directory structure
4. Make sure to exclude unnecessary files like:
   - Local development environment files (venv, __pycache__, etc.)
   - Local database files unless needed
   - `.git` directory and other version control files

### Alternative: Using File Manager in cPanel

1. Go to the **Files** section in cPanel and click on **File Manager**
2. Navigate to the application root directory
3. Use the **Upload** function to upload your project files
4. You may need to upload files in batches or as a zip archive that you extract on the server

## Step 3: Configure the Project for Production

### Create or Modify passenger_wsgi.py

If the file isn't created automatically, create a `passenger_wsgi.py` file in the application root with the following content:

```python
import os
import sys

# Add the project directory to the Python path
sys.path.insert(0, os.path.dirname(__file__))

# Point to the WSGI application
from nikoji_project.wsgi import application
