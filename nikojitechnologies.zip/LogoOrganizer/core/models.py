from django.db import models
from django.utils import timezone
from django.urls import reverse


class ServiceCategory(models.Model):
    """Category for classifying services"""
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    
    class Meta:
        verbose_name_plural = "Service Categories"
    
    def __str__(self):
        return self.name


class Service(models.Model):
    """Services offered by Nikoji Technologies"""
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    category = models.ForeignKey(ServiceCategory, on_delete=models.CASCADE, related_name='services')
    short_description = models.CharField(max_length=255)
    description = models.TextField()
    features = models.TextField(blank=True, help_text="List features, one per line")
    is_featured = models.BooleanField(default=False)
    date_added = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('service_detail', args=[self.slug])


class Project(models.Model):
    """Projects completed by Nikoji Technologies"""
    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True)
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='projects')
    client = models.CharField(max_length=150)
    short_description = models.CharField(max_length=255)
    description = models.TextField()
    duration = models.CharField(max_length=50, help_text="e.g., '3 months'", blank=True)
    completion_date = models.DateField()
    is_featured = models.BooleanField(default=False)
    
    def __str__(self):
        return self.title
    
    def get_absolute_url(self):
        return reverse('project_detail', args=[self.slug])


class Testimonial(models.Model):
    """Client testimonials"""
    client_name = models.CharField(max_length=100)
    client_company = models.CharField(max_length=100)
    client_position = models.CharField(max_length=100)
    testimonial_text = models.TextField()
    date_added = models.DateField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.client_name} - {self.client_company}"


class ContactMessage(models.Model):
    """Messages received via the contact form"""
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    date_sent = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    
    def __str__(self):
        return f"{self.name} - {self.subject}"


class ServiceRequest(models.Model):
    """Service requests received from customers"""
    STATUS_CHOICES = (
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    )
    
    name = models.CharField(max_length=100)
    company = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    service = models.ForeignKey(Service, on_delete=models.SET_NULL, null=True, blank=True)
    service_name = models.CharField(max_length=200, help_text="If service not in dropdown")
    requirements = models.TextField()
    target_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    date_submitted = models.DateTimeField(auto_now_add=True)
    date_updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.name} - {self.service or self.service_name}"
