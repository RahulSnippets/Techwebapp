from django import forms
from captcha.fields import CaptchaField
from .models import ContactMessage, ServiceRequest, Service


class ContactForm(forms.ModelForm):
    """Contact form for website visitors"""
    captcha = CaptchaField()
    
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'phone', 'subject', 'message']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Your Name', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Your Email', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Your Phone Number', 'class': 'form-control'}),
            'subject': forms.TextInput(attrs={'placeholder': 'Subject', 'class': 'form-control'}),
            'message': forms.Textarea(attrs={'placeholder': 'Your Message', 'class': 'form-control', 'rows': 5}),
        }
        
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        # Basic phone validation
        if phone and not any(c.isdigit() for c in phone):
            raise forms.ValidationError("Please enter a valid phone number with at least one digit")
        return phone


class ServiceRequestForm(forms.ModelForm):
    """Service request form for customers"""
    captcha = CaptchaField()
    
    class Meta:
        model = ServiceRequest
        fields = ['name', 'company', 'email', 'phone', 'service', 'service_name', 'requirements', 'target_date']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Your Name', 'class': 'form-control'}),
            'company': forms.TextInput(attrs={'placeholder': 'Your Company', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'Your Email', 'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'placeholder': 'Your Phone Number', 'class': 'form-control'}),
            'service': forms.Select(attrs={'class': 'form-control'}),
            'service_name': forms.TextInput(attrs={'placeholder': 'Specify if not in dropdown', 'class': 'form-control'}),
            'requirements': forms.Textarea(attrs={'placeholder': 'Please describe your requirements in detail', 'class': 'form-control', 'rows': 5}),
            'target_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        # Basic phone validation
        if phone and not any(c.isdigit() for c in phone):
            raise forms.ValidationError("Please enter a valid phone number with at least one digit")
        return phone
        
    def clean(self):
        cleaned_data = super().clean()
        service = cleaned_data.get('service')
        service_name = cleaned_data.get('service_name')
        
        if not service and not service_name:
            raise forms.ValidationError("Please either select a service or specify a service name")
            
        return cleaned_data


class SearchForm(forms.Form):
    """Form for site-wide search"""
    query = forms.CharField(
        label='Search',
        max_length=100,
        widget=forms.TextInput(attrs={'placeholder': 'Search...', 'class': 'search-input'})
    )
