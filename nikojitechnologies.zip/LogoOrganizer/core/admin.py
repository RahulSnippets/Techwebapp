from django.contrib import admin
from .models import (
    ServiceCategory, 
    Service, 
    Project, 
    Testimonial, 
    ContactMessage, 
    ServiceRequest
)


@admin.register(ServiceCategory)
class ServiceCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name',)


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'is_featured', 'date_updated')
    list_filter = ('is_featured', 'category', 'date_added')
    search_fields = ('title', 'short_description')
    prepopulated_fields = {'slug': ('title',)}
    date_hierarchy = 'date_added'


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'service', 'client', 'completion_date', 'is_featured')
    list_filter = ('service', 'is_featured', 'completion_date')
    search_fields = ('title', 'client', 'description')
    prepopulated_fields = {'slug': ('title',)}
    date_hierarchy = 'completion_date'


@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ('client_name', 'client_company', 'client_position', 'date_added', 'is_active')
    list_filter = ('is_active', 'date_added')
    search_fields = ('client_name', 'client_company', 'testimonial_text')
    date_hierarchy = 'date_added'


@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'date_sent', 'is_read')
    list_filter = ('is_read', 'date_sent')
    search_fields = ('name', 'email', 'subject', 'message')
    date_hierarchy = 'date_sent'
    readonly_fields = ('name', 'email', 'phone', 'subject', 'message', 'date_sent')

    def has_add_permission(self, request):
        return False


@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = ('name', 'company', 'service_display', 'status', 'date_submitted')
    list_filter = ('status', 'date_submitted', 'service')
    search_fields = ('name', 'company', 'email', 'requirements')
    date_hierarchy = 'date_submitted'
    readonly_fields = ('date_submitted',)
    
    def service_display(self, obj):
        return obj.service.title if obj.service else obj.service_name
    service_display.short_description = 'Service'


# Customize admin site
admin.site.site_header = 'Nikoji Technologies Administration'
admin.site.site_title = 'Nikoji Technologies Admin'
admin.site.index_title = 'Welcome to Nikoji Technologies Management Portal'
