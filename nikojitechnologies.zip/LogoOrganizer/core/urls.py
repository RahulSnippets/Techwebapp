from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('automation/', views.automation, name='automation'),
    path('innovation/', views.innovation, name='innovation'),
    path('design-development/', views.design_development, name='design_development'),
    path('testing-service/', views.testing_service, name='testing_service'),
    path('software-requirements/', views.software_requirements, name='software_requirements'),
    path('smt-solution/', views.smt_solution, name='smt_solution'),
    path('consultancy/', views.consultancy, name='consultancy'),
    path('contact/', views.contact, name='contact'),
    path('search/', views.search, name='search'),
]
