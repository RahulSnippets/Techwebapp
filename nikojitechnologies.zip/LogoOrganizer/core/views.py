from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.core.mail import send_mail, BadHeaderError
from django.conf import settings
from django.views.decorators.http import require_POST
from django.db.models import Q
from django.contrib import messages
from django.template.loader import render_to_string
from django.utils.html import strip_tags

from .models import Service, ServiceCategory, Project, Testimonial
from .forms import ContactForm, ServiceRequestForm, SearchForm


def index(request):
    """Home page view"""
    featured_services = Service.objects.filter(is_featured=True)[:3]
    featured_projects = Project.objects.filter(is_featured=True)[:3]
    
    context = {
        'featured_services': featured_services,
        'featured_projects': featured_projects,
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY,
        'delhi_coordinates': {
            'lat': 28.7041, 
            'lng': 77.1025
        }
    }
    return render(request, 'core/index.html', context)


def automation(request):
    """Automation services page"""
    categories = ['PLC', 'SCADA', 'HMI', 'VFD', 'Motor', 'Servo', 'Servo Drives', 'Panel']
    services = Service.objects.filter(
        Q(category__name__in=categories) | 
        Q(title__in=categories) | 
        Q(description__icontains=' '.join(categories))
    ).distinct()
    
    context = {
        'services': services,
        'page_title': 'Automation',
        'categories': categories,
    }
    return render(request, 'core/automation.html', context)


def innovation(request):
    """Innovation page"""
    context = {
        'page_title': 'Innovation',
        'page_subtitle': 'We Are Here to Match Your Expectations',
    }
    return render(request, 'core/innovation.html', context)


def design_development(request):
    """Design & Development page"""
    projects = Project.objects.filter(
        service__category__name__icontains='design'
    ).order_by('-completion_date')[:6]
    
    context = {
        'page_title': 'Design & Development',
        'page_subtitle': 'We Deliver What You Think',
        'projects': projects,
    }
    return render(request, 'core/design_development.html', context)


def testing_service(request):
    """Testing & Service page with service request form"""
    ict_services = Service.objects.filter(title__icontains='ICT')
    fct_services = Service.objects.filter(title__icontains='FCT')
    fpt_services = Service.objects.filter(title__icontains='FPT')
    ate_services = Service.objects.filter(title__icontains='ATE')
    
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST)
        if form.is_valid():
            service_request = form.save()
            
            # Send email notification
            try:
                subject = f"New Service Request: {service_request.service or service_request.service_name}"
                
                # Create HTML email
                html_message = render_to_string('core/emails/service_request.html', {
                    'service_request': service_request,
                })
                plain_message = strip_tags(html_message)
                
                send_mail(
                    subject,
                    plain_message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.EMAIL_HOST_USER],
                    html_message=html_message,
                    fail_silently=False,
                )
                
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': True, 'message': 'Your service request has been submitted successfully!'})
                
                messages.success(request, 'Your service request has been submitted successfully!')
                return redirect('testing_service')
                
            except BadHeaderError:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': 'Invalid header found.'})
                messages.error(request, 'Invalid header found.')
                
            except Exception as e:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': f'An error occurred: {str(e)}'})
                messages.error(request, f'An error occurred: {str(e)}')
                
        elif request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = ServiceRequestForm()
    
    context = {
        'page_title': 'Testing & Service',
        'ict_services': ict_services,
        'fct_services': fct_services,
        'fpt_services': fpt_services,
        'ate_services': ate_services,
        'form': form,
    }
    return render(request, 'core/testing_service.html', context)


def software_requirements(request):
    """Software & Requirements page with inquiry form"""
    software_projects = Project.objects.filter(
        Q(service__title__icontains='software') | 
        Q(service__description__icontains='software')
    ).order_by('-completion_date')
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            contact_message = form.save()
            
            # Send email notification
            try:
                subject = f"New Requirement Inquiry: {contact_message.subject}"
                
                # Create HTML email
                html_message = render_to_string('core/emails/contact_message.html', {
                    'message': contact_message,
                    'is_requirement': True,
                })
                plain_message = strip_tags(html_message)
                
                send_mail(
                    subject,
                    plain_message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.EMAIL_HOST_USER],
                    html_message=html_message,
                    fail_silently=False,
                )
                
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': True, 'message': 'Your inquiry has been submitted successfully!'})
                
                messages.success(request, 'Your inquiry has been submitted successfully!')
                return redirect('software_requirements')
                
            except BadHeaderError:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': 'Invalid header found.'})
                messages.error(request, 'Invalid header found.')
                
            except Exception as e:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': f'An error occurred: {str(e)}'})
                messages.error(request, f'An error occurred: {str(e)}')
                
        elif request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = ContactForm()
    
    context = {
        'page_title': 'Software & Requirements',
        'software_projects': software_projects,
        'form': form,
    }
    return render(request, 'core/software_requirements.html', context)


def smt_solution(request):
    """SMT Solution page"""
    context = {
        'page_title': 'SMT Solution',
        'solutions': Service.objects.filter(
            Q(title__icontains='SMT') | 
            Q(description__icontains='SMT') | 
            Q(title__icontains='EMS') | 
            Q(description__icontains='EMS')
        )
    }
    return render(request, 'core/smt_solution.html', context)


def consultancy(request):
    """Consultancy page"""
    context = {
        'page_title': 'Consultancy',
        'services': Service.objects.filter(
            Q(category__name__icontains='consultancy') | 
            Q(title__icontains='consultancy') | 
            Q(description__icontains='consultancy')
        ),
    }
    return render(request, 'core/consultancy.html', context)


def contact(request):
    """Contact page with contact form"""
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            contact_message = form.save()
            
            # Send email notification
            try:
                subject = f"New Contact Message: {contact_message.subject}"
                
                # Create HTML email
                html_message = render_to_string('core/emails/contact_message.html', {
                    'message': contact_message,
                    'is_requirement': False,
                })
                plain_message = strip_tags(html_message)
                
                send_mail(
                    subject,
                    plain_message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.EMAIL_HOST_USER],
                    html_message=html_message,
                    fail_silently=False,
                )
                
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': True, 'message': 'Your message has been sent successfully!'})
                
                messages.success(request, 'Your message has been sent successfully!')
                return redirect('contact')
                
            except BadHeaderError:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': 'Invalid header found.'})
                messages.error(request, 'Invalid header found.')
                
            except Exception as e:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'success': False, 'message': f'An error occurred: {str(e)}'})
                messages.error(request, f'An error occurred: {str(e)}')
                
        elif request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': False, 'errors': form.errors})
    else:
        form = ContactForm()
    
    context = {
        'page_title': 'Contact Us',
        'form': form,
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY,
        'delhi_coordinates': {
            'lat': 28.7041, 
            'lng': 77.1025
        }
    }
    return render(request, 'core/contact.html', context)


def search(request):
    """Search functionality"""
    form = SearchForm(request.GET)
    results = []
    query = ""
    
    if form.is_valid():
        query = form.cleaned_data['query']
        results = Service.objects.filter(
            Q(title__icontains=query) | 
            Q(description__icontains=query)
        )
        
        # Add projects to results
        project_results = Project.objects.filter(
            Q(title__icontains=query) | 
            Q(description__icontains=query) | 
            Q(client__icontains=query)
        )
        
    context = {
        'form': form,
        'query': query,
        'services': results,
        'projects': project_results if 'project_results' in locals() else [],
    }
    return render(request, 'core/search_results.html', context)
