/**
 * Nikoji Technologies - Forms JavaScript
 * Handles AJAX form submissions and validation
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize contact form
    initContactForm();
    
    // Initialize service request form
    initServiceRequestForm();
});

/**
 * Initialize contact form with AJAX submission
 */
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.innerHTML = 'Sending...';
            submitBtn.disabled = true;
            
            // Clear previous feedback
            clearFormFeedback(contactForm);
            
            // Get form data
            const formData = new FormData(contactForm);
            
            // Send AJAX request
            fetch(contactForm.getAttribute('action'), {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCookie('csrftoken')
                }
            })
            .then(response => response.json())
            .then(data => {
                // Reset button
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                
                if (data.success) {
                    // Show success message
                    showFormFeedback(contactForm, 'success', data.message);
                    
                    // Reset form
                    contactForm.reset();
                    
                    // Refresh CAPTCHA
                    refreshCaptcha();
                } else {
                    // Show errors
                    if (data.errors) {
                        showFormErrors(contactForm, data.errors);
                    } else {
                        showFormFeedback(contactForm, 'error', data.message || 'An error occurred. Please try again.');
                    }
                }
            })
            .catch(error => {
                // Reset button
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                
                // Show error message
                showFormFeedback(contactForm, 'error', 'An error occurred. Please try again.');
                console.error('Error:', error);
            });
        });
    }
}

/**
 * Initialize service request form with AJAX submission
 */
function initServiceRequestForm() {
    const serviceRequestForm = document.getElementById('serviceRequestForm');
    
    if (serviceRequestForm) {
        // Toggle service_name field based on service selection
        const serviceSelect = serviceRequestForm.querySelector('#id_service');
        const serviceNameField = serviceRequestForm.querySelector('#id_service_name').closest('.form-group');
        
        if (serviceSelect && serviceNameField) {
            // Initial state
            if (serviceSelect.value === '') {
                serviceNameField.style.display = 'block';
            } else {
                serviceNameField.style.display = 'none';
            }
            
            // On change
            serviceSelect.addEventListener('change', function() {
                if (this.value === '') {
                    serviceNameField.style.display = 'block';
                } else {
                    serviceNameField.style.display = 'none';
                }
            });
        }
        
        // Form submission
        serviceRequestForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading state
            const submitBtn = serviceRequestForm.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            submitBtn.innerHTML = 'Submitting...';
            submitBtn.disabled = true;
            
            // Clear previous feedback
            clearFormFeedback(serviceRequestForm);
            
            // Get form data
            const formData = new FormData(serviceRequestForm);
            
            // Send AJAX request
            fetch(serviceRequestForm.getAttribute('action'), {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': getCookie('csrftoken')
                }
            })
            .then(response => response.json())
            .then(data => {
                // Reset button
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                
                if (data.success) {
                    // Show success message
                    showFormFeedback(serviceRequestForm, 'success', data.message);
                    
                    // Reset form
                    serviceRequestForm.reset();
                    
                    // Refresh CAPTCHA
                    refreshCaptcha();
                } else {
                    // Show errors
                    if (data.errors) {
                        showFormErrors(serviceRequestForm, data.errors);
                    } else {
                        showFormFeedback(serviceRequestForm, 'error', data.message || 'An error occurred. Please try again.');
                    }
                }
            })
            .catch(error => {
                // Reset button
                submitBtn.innerHTML = originalBtnText;
                submitBtn.disabled = false;
                
                // Show error message
                showFormFeedback(serviceRequestForm, 'error', 'An error occurred. Please try again.');
                console.error('Error:', error);
            });
        });
    }
}

/**
 * Show form feedback message
 */
function showFormFeedback(form, type, message) {
    const feedbackDiv = document.createElement('div');
    feedbackDiv.className = `form-feedback ${type}`;
    feedbackDiv.innerHTML = message;
    
    form.prepend(feedbackDiv);
    
    // Scroll to feedback
    feedbackDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

/**
 * Clear form feedback messages
 */
function clearFormFeedback(form) {
    const feedbackDivs = form.querySelectorAll('.form-feedback');
    feedbackDivs.forEach(div => div.remove());
    
    const errorMessages = form.querySelectorAll('.form-error');
    errorMessages.forEach(message => message.remove());
}

/**
 * Show form validation errors
 */
function showFormErrors(form, errors) {
    for (const field in errors) {
        const inputField = form.querySelector(`#id_${field}`);
        if (inputField) {
            inputField.classList.add('is-invalid');
            
            const errorMessage = document.createElement('div');
            errorMessage.className = 'form-error';
            errorMessage.innerHTML = errors[field].join('<br>');
            
            const formGroup = inputField.closest('.form-group');
            formGroup.appendChild(errorMessage);
        }
    }
    
    // Show general error
    showFormFeedback(form, 'error', 'Please correct the errors below and try again.');
}

/**
 * Refresh CAPTCHA image
 */
function refreshCaptcha() {
    const captchaImage = document.querySelector('.captcha img');
    const captchaInput = document.querySelector('input[name="captcha_0"]');
    
    if (captchaImage && captchaInput) {
        // Get the current timestamp to prevent caching
        const timestamp = new Date().getTime();
        const captchaUrl = captchaImage.src.split('?')[0] + '?' + timestamp;
        
        // Update the image
        captchaImage.src = captchaUrl;
        
        // Reset the input
        captchaInput.value = '';
    }
}

/**
 * Get CSRF cookie for AJAX requests
 */
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
