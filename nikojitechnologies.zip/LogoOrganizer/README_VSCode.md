# Nikoji Technologies - VS Code Setup Guide

This guide will help you set up the Nikoji Technologies website project in Visual Studio Code (VS Code) for development purposes.

## Prerequisites

Before you begin, ensure you have the following installed on your system:

1. **Python** (3.8 or newer) - [Download Python](https://www.python.org/downloads/)
2. **Git** - [Download Git](https://git-scm.com/downloads)
3. **Visual Studio Code** - [Download VS Code](https://code.visualstudio.com/download)
4. **SQLite** - This is included with Python, but you may want to install a GUI like [DB Browser for SQLite](https://sqlitebrowser.org/dl/) for database management

## VS Code Extensions

Install the following VS Code extensions to enhance your development experience:

1. **Python** - Microsoft's Python extension
2. **Django** - Provides Django template language support
3. **SQLite** - For database management within VS Code
4. **HTML CSS Support** - For improved HTML/CSS editing
5. **Live Server** - For previewing static files
6. **Prettier** - Code formatter

You can install these extensions from the Extensions view in VS Code (Ctrl+Shift+X or Cmd+Shift+X).

## Project Setup

Follow these steps to set up the project in VS Code:

### 1. Clone the Repository

```bash
git clone <repository-url>
cd nikoji-technologies
