-- Nikoji Technologies Database Schema
-- This file contains the SQL schema for creating all required tables in SQLite

-- ServiceCategory table
CREATE TABLE IF NOT EXISTS "core_servicecategory" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "name" VARCHAR(100) NOT NULL,
    "slug" VARCHAR(100) NOT NULL UNIQUE,
    "description" TEXT
);

-- Service table
CREATE TABLE IF NOT EXISTS "core_service" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "title" VARCHAR(200) NOT NULL,
    "slug" VARCHAR(200) NOT NULL UNIQUE,
    "category_id" INTEGER NOT NULL,
    "short_description" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "features" TEXT,
    "is_featured" BOOLEAN NOT NULL,
    "date_added" DATETIME NOT NULL,
    "date_updated" DATETIME NOT NULL,
    FOREIGN KEY ("category_id") REFERENCES "core_servicecategory" ("id") ON DELETE CASCADE
);

-- Project table
CREATE TABLE IF NOT EXISTS "core_project" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "title" VARCHAR(200) NOT NULL,
    "slug" VARCHAR(200) NOT NULL UNIQUE,
    "service_id" INTEGER NOT NULL,
    "client" VARCHAR(150) NOT NULL,
    "short_description" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "duration" VARCHAR(50),
    "completion_date" DATE NOT NULL,
    "is_featured" BOOLEAN NOT NULL,
    FOREIGN KEY ("service_id") REFERENCES "core_service" ("id") ON DELETE CASCADE
);

-- Testimonial table
CREATE TABLE IF NOT EXISTS "core_testimonial" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "client_name" VARCHAR(100) NOT NULL,
    "client_company" VARCHAR(100) NOT NULL,
    "client_position" VARCHAR(100) NOT NULL,
    "testimonial_text" TEXT NOT NULL,
    "date_added" DATE NOT NULL,
    "is_active" BOOLEAN NOT NULL
);

-- ContactMessage table
CREATE TABLE IF NOT EXISTS "core_contactmessage" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "name" VARCHAR(100) NOT NULL,
    "email" VARCHAR(254) NOT NULL,
    "phone" VARCHAR(20) NOT NULL,
    "subject" VARCHAR(200) NOT NULL,
    "message" TEXT NOT NULL,
    "date_sent" DATETIME NOT NULL,
    "is_read" BOOLEAN NOT NULL
);

-- ServiceRequest table
CREATE TABLE IF NOT EXISTS "core_servicerequest" (
    "id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "name" VARCHAR(100) NOT NULL,
    "company" VARCHAR(100) NOT NULL,
    "email" VARCHAR(254) NOT NULL,
    "phone" VARCHAR(20) NOT NULL,
    "service_id" INTEGER,
    "service_name" VARCHAR(200) NOT NULL,
    "requirements" TEXT NOT NULL,
    "target_date" DATE,
    "status" VARCHAR(20) NOT NULL,
    "date_submitted" DATETIME NOT NULL,
    "date_updated" DATETIME NOT NULL,
    FOREIGN KEY ("service_id") REFERENCES "core_service" ("id") ON DELETE SET NULL
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS "core_service_category_id_idx" ON "core_service" ("category_id");
CREATE INDEX IF NOT EXISTS "core_service_is_featured_idx" ON "core_service" ("is_featured");
CREATE INDEX IF NOT EXISTS "core_project_service_id_idx" ON "core_project" ("service_id");
CREATE INDEX IF NOT EXISTS "core_project_is_featured_idx" ON "core_project" ("is_featured");
CREATE INDEX IF NOT EXISTS "core_testimonial_is_active_idx" ON "core_testimonial" ("is_active");
CREATE INDEX IF NOT EXISTS "core_contactmessage_is_read_idx" ON "core_contactmessage" ("is_read");
CREATE INDEX IF NOT EXISTS "core_servicerequest_service_id_idx" ON "core_servicerequest" ("service_id");
CREATE INDEX IF NOT EXISTS "core_servicerequest_status_idx" ON "core_servicerequest" ("status");

-- Insert default service categories
INSERT INTO "core_servicecategory" ("name", "slug", "description")
VALUES 
    ('Automation', 'automation', 'Industrial automation services including PLC, SCADA, HMI, and control systems'),
    ('Testing', 'testing', 'Testing services including ICT, FCT, FPT, and ATE solutions'),
    ('Software Development', 'software-development', 'Custom software solutions for industrial applications'),
    ('Consultancy', 'consultancy', 'Expert consultancy services for industrial automation and manufacturing processes'),
    ('SMT Solutions', 'smt-solutions', 'Surface Mount Technology solutions for electronics manufacturing');

-- Sample service data for initial setup
INSERT INTO "core_service" ("title", "slug", "category_id", "short_description", "description", "features", "is_featured", "date_added", "date_updated")
VALUES
    ('PLC Programming & Integration', 'plc-programming-integration', 1, 
     'Expert PLC programming and system integration services for industrial automation',
     'Our PLC programming and integration services provide comprehensive solutions for automating industrial processes. We work with all major PLC platforms including Allen-Bradley, Siemens, Mitsubishi, and Omron to create reliable, efficient control systems tailored to your specific requirements.', 
     'Custom PLC programming\nControl system architecture\nHMI integration\nSystem upgrades and migrations\nTroubleshooting and optimization',
     1, datetime('now'), datetime('now')),
     
    ('SCADA System Development', 'scada-system-development', 1,
     'Comprehensive SCADA solutions for monitoring and control of industrial processes',
     'Our SCADA system development services provide powerful visualization, data collection, and control capabilities for your industrial operations. We design and implement scalable SCADA solutions that deliver real-time insights into your processes, enabling informed decision-making and improved operational efficiency.',
     'Custom HMI design\nReal-time data visualization\nAlarm management\nHistorical trending\nRemote access capabilities\nDatabase integration',
     1, datetime('now'), datetime('now')),
     
    ('In-Circuit Testing (ICT)', 'in-circuit-testing', 2,
     'Advanced ICT solutions for detecting manufacturing defects in electronic assemblies',
     'Our In-Circuit Testing services provide thorough inspection of PCB assemblies to detect manufacturing defects such as shorts, opens, missing components, and incorrect values. Using state-of-the-art test equipment, we develop comprehensive test strategies to ensure the quality and reliability of your electronic products.',
     'Custom test fixture design\nTest program development\nFault diagnosis and reporting\nIntegration with production systems\nYield improvement recommendations',
     1, datetime('now'), datetime('now')),
     
    ('Custom Software Development', 'custom-software-development', 3,
     'Tailored software solutions for industrial applications and process control',
     'Our custom software development services address the unique requirements of industrial environments with solutions designed specifically for your operational needs. From data acquisition and analysis to process control and monitoring, we create robust, user-friendly software that enhances your capabilities and improves efficiency.',
     'Requirements analysis\nUser-centered design\nAgile development methodology\nComprehensive testing\nTraining and documentation\nOngoing support and maintenance',
     0, datetime('now'), datetime('now')),
     
    ('SMT Assembly Services', 'smt-assembly-services', 5,
     'High-precision SMT assembly for reliable electronic product manufacturing',
     'Our Surface Mount Technology assembly services deliver high-quality electronic manufacturing with precision placement and reliable soldering. From prototype to high-volume production, we provide complete SMT solutions including component procurement, assembly, inspection, and testing to ensure superior quality in your electronic products.',
     'High-speed automated assembly\nFine-pitch component capability\nBGA and QFN placement\nAOI and X-ray inspection\nRework and repair services\nFull traceability',
     0, datetime('now'), datetime('now')),
     
    ('Process Optimization Consultancy', 'process-optimization-consultancy', 4,
     'Expert guidance for improving efficiency and quality in industrial processes',
     'Our process optimization consultancy services help manufacturers identify inefficiencies, reduce waste, and improve quality throughout their operations. Through detailed analysis, lean methodologies, and industry best practices, we develop practical recommendations that deliver measurable improvements in productivity and cost-effectiveness.',
     'Process mapping and analysis\nBottleneck identification\nLean manufacturing principles\nWorkflow optimization\nQuality improvement strategies\nPerformance metrics and monitoring',
     0, datetime('now'), datetime('now'));
