# Maintenance Guide for Nikoji Technologies Website

This guide provides instructions for maintaining the Nikoji Technologies website after deployment.

## Regular Maintenance Tasks

### 1. Database Backups

Perform regular database backups to prevent data loss:

#### Automated Backups via cPanel
1. Log in to cPanel
2. Go to "Backup" or "Backup Wizard"
3. Schedule regular backups of your PostgreSQL database

#### Manual Database Backup
```bash
# SSH into your server
ssh username@your-server.com

# Navigate to your project directory
cd public_html/nikoji_tech

# Activate virtual environment (if used)
source ../env/bin/activate

# Perform a database dump
python manage.py dumpdata > backups/backup_$(date +%Y%m%d).json
```

### 2. Security Updates

#### Django and Package Updates
1. Check for Django security updates regularly at [Django security releases](https://docs.djangoproject.com/en/dev/releases/security/)
2. Update packages when security patches are released:

```bash
# Update a specific package
pip install --upgrade django

# Update all packages (be cautious with this)
pip install --upgrade -r requirements.txt
```

#### Server Updates
1. Keep your server OS and software updated
2. Apply security patches promptly

### 3. Monitoring

#### Check Server Logs
```bash
# Check error logs in cPanel
# Or via SSH:
cd ~/logs
tail -f error_log
```

#### Check Django Logs
If you've set up logging in Django's settings:
```bash
cat /path/to/logs/django.log
```

#### Monitor Performance
1. Use cPanel's Resource Usage feature
2. Consider setting up external monitoring services
3. Watch for slow database queries and page load times

### 4. Content Updates

#### Adding/Updating Services
1. Log in to the admin panel (yourdomain.com/admin)
2. Navigate to "Services"
3. Add new services or update existing ones

#### Managing Projects
1. In the admin panel, go to "Projects"
2. Add new projects or update project details

#### Managing Testimonials
1. In the admin panel, go to "Testimonials"
2. Add, edit, or deactivate testimonials

### 5. Database Maintenance

#### Optimize Performance
Occasionally optimize your PostgreSQL database:
```bash
# Connect to PostgreSQL
psql -U your_db_user -d your_db_name

# Run VACUUM to analyze and optimize tables
VACUUM ANALYZE;

# Exit PostgreSQL
\q
```

#### Check Database Size
```bash
# Connect to PostgreSQL
psql -U your_db_user -d your_db_name

# Check database size
SELECT pg_size_pretty(pg_database_size('your_db_name'));

# Check table sizes
SELECT table_name, pg_size_pretty(pg_total_relation_size(table_name))
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY pg_total_relation_size(table_name) DESC;
```

## Troubleshooting Common Issues

### 1. Website is Down

#### Check Server Status
1. Verify the hosting server is running
2. Check if other websites on the same server are accessible

#### Check Django Process
```bash
# SSH into your server
ssh username@your-server.com

# Check if Python/Django process is running
ps aux | grep python

# Restart Python application in cPanel
# Or restart manually if applicable
```

### 2. Database Connection Issues

#### Check PostgreSQL Service
```bash
# Check if PostgreSQL is running
service postgresql status

# Restart PostgreSQL if needed
service postgresql restart
```

#### Check Database Credentials
1. Verify credentials in `.env` file
2. Test connection manually:
```bash
psql -U your_db_user -h your_db_host -d your_db_name
```

### 3. Static Files Not Loading

#### Check Permissions
```bash
# Ensure proper permissions on static files
cd /path/to/static
ls -la

# Set proper permissions if needed
chmod -R 644 .
find . -type d -exec chmod 755 {} \;
```

#### Run collectstatic Again
```bash
cd /path/to/project
python manage.py collectstatic --no-input
```

### 4. Email Functionality Issues

1. Verify email settings in `.env`
2. Test email settings:
```bash
cd /path/to/project
python manage.py shell

# In Django shell
from django.core.mail import send_mail
send_mail('Test Subject', 'Test message', 'from@example.com', ['to@example.com'])
```

## Updating the Website

### 1. Minor Content Updates

Use the admin panel at yourdomain.com/admin for:
- Adding/updating services
- Managing projects
- Adding testimonials
- Handling contact messages

### 2. Code Updates

When deploying code updates:

1. Back up the current site files and database
2. Upload new files to the server
3. Run migrations if there are database changes:
```bash
python manage.py migrate
```
4. Collect static files if there are new assets:
```bash
python manage.py collectstatic --no-input
```
5. Restart the application in cPanel

### 3. Template/Frontend Updates

1. Back up existing template files
2. Upload new HTML/CSS/JS files
3. Test thoroughly across different devices and browsers

## Performance Optimization

### 1. Database Queries

If the site becomes slow:
1. Use Django Debug Toolbar in development to identify slow queries
2. Optimize database indexes
3. Add caching for frequently accessed data

### 2. Static File Optimization

1. Compress images before uploading
2. Minify CSS and JavaScript files
3. Consider using a CDN for static assets

### 3. Server Optimization

1. Adjust PostgreSQL settings for better performance
2. Consider adding server-side caching
3. Upgrade hosting plan if traffic increases significantly

## Security Best Practices

### 1. Regular Password Changes

1. Change admin passwords regularly
2. Use strong, unique passwords

### 2. Keep Software Updated

1. Keep Django and all packages up to date
2. Update server software regularly

### 3. Monitor for Suspicious Activity

1. Check access logs for unusual patterns
2. Watch for unauthorized admin login attempts

### 4. Secure File Permissions

1. Ensure proper file permissions
2. Make sure sensitive files like `.env` are not publicly accessible

## Contact Support

If you need assistance with maintenance or encounter issues:
- Email: support@nikojitechnologies.com
- Phone: [Your support phone number]