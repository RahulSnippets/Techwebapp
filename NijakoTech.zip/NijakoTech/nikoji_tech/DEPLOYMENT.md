# Deployment Guide for Nikoji Technologies Website

This guide provides step-by-step instructions for deploying the Nikoji Technologies website to a cPanel hosting environment.

## Prerequisites

- A cPanel hosting account with Python support
- Access to cPanel's File Manager
- A domain or subdomain pointed to your hosting account
- PostgreSQL database (most cPanel installations have this)

## Step 1: Prepare Your Files for Deployment

Before uploading to cPanel, prepare your project:

1. Make sure `DEBUG = False` in your production settings
2. Update `ALLOWED_HOSTS` to include your domain
3. Set up proper database configuration
4. Generate and use a secure SECRET_KEY
5. Make sure all static files are collected

## Step 2: Create a Deployment Package

Create a ZIP archive containing:

- The entire `nikoji_tech` directory
- `.htaccess` (included in the project)
- `passenger_wsgi.py` (included in the project)
- `requirements.txt` (included in the project)

Exclude these files and directories:

- `__pycache__` directories
- `.pyc` files
- `.env` file (you'll create a new one on the server)
- `venv` directory
- Any local development files

## Step 3: Upload to cPanel

1. Log in to your cPanel account
2. Navigate to File Manager
3. Go to the public_html directory (or a subdirectory if using a subdomain)
4. Click on "Upload" and select your ZIP file
5. Once uploaded, extract the ZIP file

## Step 4: Setup Python Application in cPanel

### Using Python Selector (if available)

1. In cPanel, locate "Python Selector" or "Setup Python App"
2. Create a new Python application:
   - Application Path: Select the directory where you extracted the files
   - Python Version: Select Python 3.10 or higher
   - Application Startup File: `passenger_wsgi.py`
   - Application URL: Your domain or subdomain
   - Application Entry Point: `application`
3. Click "Create" or "Setup"

### Manual Setup (if Python Selector is not available)

1. SSH into your server (terminal access required)
2. Navigate to your application directory
3. Create a virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Make sure `passenger_wsgi.py` has execute permissions:
   ```bash
   chmod 755 passenger_wsgi.py
   ```

## Step 5: Configure Environment Variables

Create a `.env` file in your application's root directory with:

```
DEBUG=False
SECRET_KEY=your_secure_key_here
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
DATABASE_URL=postgres://username:password@localhost:5432/database_name
```

Replace placeholders with your actual values.

## Step 6: Set Up PostgreSQL Database

1. In cPanel, go to "PostgreSQL Databases"
2. Create a new database
3. Create a database user and assign it to the database
4. Note the database name, username, password, and host
5. Update your `.env` file with these credentials

## Step 7: Run Database Migrations

1. SSH into your server or use cPanel Terminal
2. Navigate to your application directory
3. Activate the virtual environment:
   ```bash
   source venv/bin/activate
   ```
4. Run migrations:
   ```bash
   cd nikoji_tech
   python manage.py migrate
   ```
5. Create a superuser:
   ```bash
   python manage.py createsuperuser
   ```

## Step 8: Collect Static Files

```bash
python manage.py collectstatic --no-input
```

## Step 9: Configure HTTPS (Recommended)

1. In cPanel, go to "SSL/TLS" or "Let's Encrypt SSL"
2. Follow the wizard to obtain and install an SSL certificate for your domain

## Step 10: Test Your Deployment

1. Visit your domain in a web browser
2. Check that all pages load correctly
3. Test the admin interface at yourdomain.com/admin
4. Submit the contact form to ensure email functionality
5. Check that all static files (CSS, JS, images) are loading

## Troubleshooting Common Issues

### Application Error or 500 Server Error

1. Check cPanel error logs
2. Verify database connection
3. Ensure all environment variables are set correctly
4. Check file permissions (directories: 755, files: 644)

### Static Files Not Loading

1. Check paths in settings.py
2. Run collectstatic again
3. Verify that STATIC_ROOT is correctly set
4. Check file permissions on static files

### Database Connection Issues

1. Verify database credentials in `.env`
2. Confirm database server is running
3. Check if your hosting has specific requirements for PostgreSQL connections

### WSGI Application Not Loading

1. Ensure passenger_wsgi.py has correct permissions (755)
2. Verify path settings in the file
3. Check cPanel logs for specific Python errors

## Maintenance Tasks

### Regular Backups

1. In cPanel, use "Backup" or "Backup Wizard"
2. Schedule regular database backups
3. Export your database periodically:
   ```bash
   python manage.py dumpdata > database_backup.json
   ```

### Updating the Application

1. Take a backup of your current application and database
2. Upload new files to the server
3. Run migrations if there are database changes
4. Collect static files if there are new or changed assets
5. Restart the application through Python Selector

### Monitoring

1. Check server logs regularly
2. Monitor database performance
3. Set up uptime monitoring for your domain

## Contact Support

If you encounter issues with your deployment, contact:
- Nikoji Technologies Support: support@nikojitechnologies.com