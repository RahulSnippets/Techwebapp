import os
import sys

# Add the application directory to the Python path
sys.path.insert(0, os.path.dirname(__file__))

# Set up environment variables
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nikoji_tech.settings')

# Import the WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()