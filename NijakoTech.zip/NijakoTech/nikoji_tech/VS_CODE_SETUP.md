# VS Code Setup Guide for Nikoji Technologies Website

This guide provides step-by-step instructions for setting up and running the Nikoji Technologies website in Visual Studio Code (VS Code).

## Prerequisites

- [Visual Studio Code](https://code.visualstudio.com/) installed on your system
- [Python](https://www.python.org/downloads/) (version 3.10 or higher) installed
- [PostgreSQL](https://www.postgresql.org/download/) installed and running
- [Git](https://git-scm.com/downloads) (optional but recommended)

## Step 1: Install Essential VS Code Extensions

Open VS Code and install these extensions for optimal development experience:

1. **Python** (Microsoft) - Python language support
2. **Django** (Baptiste Darthenay) - Django template language support
3. **SQLTools** - Database management within VS Code
4. **PostgreSQL** - PostgreSQL integration for VS Code
5. **IntelliSense for CSS** - CSS auto-completion
6. **HTML CSS Support** - HTML/CSS language support
7. **ESLint** - JavaScript linting
8. **Prettier** - Code formatting
9. **Better Comments** - Improved code comments
10. **Git Graph** (if using Git) - Visualize Git history

Install extensions from the Extensions view (Ctrl+Shift+X or Cmd+Shift+X on Mac).

## Step 2: Clone or Download the Project

### Option 1: Using Git (Recommended)

1. Open VS Code
2. Open the Command Palette (Ctrl+Shift+P or Cmd+Shift+P on Mac)
3. Type "Git: Clone" and select it
4. Enter the repository URL and select a local directory

### Option 2: Manual Download

1. Download the project as a ZIP file
2. Extract it to your preferred location
3. Open VS Code
4. Go to File > Open Folder and select the extracted project folder

## Step 3: Set Up a Python Virtual Environment

1. Open VS Code's integrated terminal (View > Terminal or Ctrl+`)
2. Navigate to the project directory if not already there
3. Create a virtual environment:

```bash
# Windows
python -m venv venv

# macOS/Linux
python3 -m venv venv
```

4. Activate the virtual environment:

```bash
# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

5. VS Code might ask to select this as the Python interpreter. If not:
   - Open the Command Palette (Ctrl+Shift+P or Cmd+Shift+P on Mac)
   - Type "Python: Select Interpreter"
   - Choose the virtual environment you just created

## Step 4: Install Project Dependencies

With the virtual environment activated, install the required packages:

```bash
cd nikoji_tech
pip install -r requirements.txt
```

## Step 5: Configure PostgreSQL Database

1. Create a PostgreSQL database for the project:

```bash
# Connect to PostgreSQL
psql -U postgres

# In PostgreSQL console
CREATE DATABASE nikoji_db;
CREATE USER nikoji_user WITH PASSWORD 'your_password';
ALTER ROLE nikoji_user SET client_encoding TO 'utf8';
ALTER ROLE nikoji_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE nikoji_user SET timezone TO 'UTC';
GRANT ALL PRIVILEGES ON DATABASE nikoji_db TO nikoji_user;
\q
```

2. Create a `.env` file in the `nikoji_tech` directory with the following content:

```
DEBUG=True
SECRET_KEY=your_development_secret_key
ALLOWED_HOSTS=localhost,127.0.0.1

# Update these values with your PostgreSQL credentials
DATABASE_URL=postgres://nikoji_user:your_password@localhost:5432/nikoji_db
```

## Step 6: Configure VS Code for Django

1. Create a `.vscode` directory in the project root (if it doesn't exist)
2. Create a `settings.json` file inside it with the following content:

```json
{
    "python.linting.enabled": true,
    "python.linting.pylintEnabled": true,
    "python.linting.pylintArgs": [
        "--load-plugins=pylint_django",
        "--django-settings-module=nikoji_tech.settings"
    ],
    "python.formatting.provider": "autopep8",
    "editor.formatOnSave": true,
    "editor.rulers": [
        88
    ],
    "files.exclude": {
        "**/__pycache__": true,
        "**/*.pyc": true
    },
    "emmet.includeLanguages": {
        "django-html": "html"
    }
}
```

3. Create a `launch.json` file in the `.vscode` directory for debugging:

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Django",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/nikoji_tech/manage.py",
            "args": [
                "runserver",
                "0.0.0.0:8000"
            ],
            "django": true,
            "justMyCode": true
        }
    ]
}
```

## Step 7: Run Migrations

In the terminal (with virtual environment activated):

```bash
cd nikoji_tech
python manage.py migrate
```

## Step 8: Create a Superuser (Admin)

```bash
python manage.py createsuperuser
```

Follow the prompts to create an admin user.

## Step 9: Run the Development Server

### Option 1: Using Terminal

```bash
python manage.py runserver 0.0.0.0:8000
```

### Option 2: Using VS Code Debugger

1. Click on the "Run and Debug" icon in the sidebar (or press F5)
2. Select "Django" from the dropdown menu
3. Click the green play button

## Step 10: Access the Website

- Frontend: http://127.0.0.1:8000/
- Admin Panel: http://127.0.0.1:8000/admin/

## Additional VS Code Tips for Django Development

### 1. Useful Keyboard Shortcuts

- Ctrl+P (Cmd+P on Mac): Quick open files
- Ctrl+Shift+F (Cmd+Shift+F on Mac): Search across all files
- F5: Start debugging
- Ctrl+` (Cmd+` on Mac): Toggle terminal
- Alt+Shift+F (Option+Shift+F on Mac): Format document

### 2. Using the Django Extension

The Django extension provides features like:
- Template syntax highlighting
- Go to definition for template tags
- Snippets for Django templates

### 3. Database Management with SQLTools

1. Click on the SQLTools icon in the sidebar
2. Add a new connection with your PostgreSQL credentials
3. Browse and query your database directly from VS Code

### 4. Debugging Django Templates

1. In your Django views, add `import pdb; pdb.set_trace()` where you want to set a breakpoint
2. When the code hits this line, you'll get an interactive debugger in the terminal

### 5. Working with Static Files

VS Code provides good support for working with CSS, JavaScript, and images in your static files directory.

### 6. Git Integration

If using Git for version control:
1. Click the Source Control icon in the sidebar
2. Stage changes, commit, push, and pull directly from VS Code
3. Use the Git Graph extension to visualize your repository's history

## Troubleshooting

### Python Path Issues

If VS Code can't find your Python interpreter:
1. Open Command Palette (Ctrl+Shift+P or Cmd+Shift+P on Mac)
2. Run "Python: Select Interpreter"
3. Choose the Python from your virtual environment

### Database Connection Issues

If you encounter database errors:
1. Verify PostgreSQL is running
2. Check the credentials in your `.env` file
3. Ensure the database exists and the user has proper permissions

### Django Module Not Found

If VS Code can't find Django modules:
1. Make sure you've activated the virtual environment
2. Verify Django is installed (`pip list`)
3. Restart VS Code

### Static Files Not Loading

1. Check that `DEBUG` is set to `True` in development
2. Verify your static files settings in `settings.py`
3. Run `python manage.py collectstatic` if needed

## Additional Resources

- [VS Code Documentation](https://code.visualstudio.com/docs)
- [Django Documentation](https://docs.djangoproject.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Python in VS Code](https://code.visualstudio.com/docs/python/python-tutorial)