/**
 * Nikoji Technologies - Main JavaScript
 * Handles interactive features of the website
 */

/**
 * Initialize animations on page load
 */
function initAnimations() {
    // Add animation classes to elements as they come into view
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    if (animatedElements.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Get the animation class from the data attribute or use a default
                    const animationClass = entry.target.dataset.animation || 'animate__fadeIn';
                    entry.target.classList.add('animate__animated', animationClass);
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });
        
        animatedElements.forEach(element => {
            observer.observe(element);
        });
    }
}

/**
 * Add scroll effect to header
 */
function initHeaderScrollEffect() {
    const header = document.querySelector('.header');
    if (header) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    }
}

/**
 * Format prices with Indian Rupee symbol
 */
function initRupeePriceFormatting() {
    const priceElements = document.querySelectorAll('.price');
    
    if (priceElements.length > 0) {
        priceElements.forEach(element => {
            const value = parseFloat(element.innerText.replace(/[^\d.]/g, ''));
            if (!isNaN(value)) {
                // Format with Indian numbering system (lakhs, crores)
                const formatter = new Intl.NumberFormat('en-IN', {
                    style: 'currency',
                    currency: 'INR',
                    minimumFractionDigits: 0
                });
                element.innerText = formatter.format(value);
            }
        });
    }
}

/**
 * Initialize animated counters
 */
function initCounters() {
    const counters = document.querySelectorAll('.counter');
    
    if (counters.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = entry.target;
                    const targetValue = parseInt(target.dataset.target);
                    const duration = parseInt(target.dataset.duration || 2000);
                    let startTime = null;
                    let currentValue = 0;
                    
                    function animateCounter(timestamp) {
                        if (!startTime) startTime = timestamp;
                        const progress = timestamp - startTime;
                        
                        if (progress < duration) {
                            currentValue = Math.floor((targetValue * progress) / duration);
                            target.innerText = currentValue;
                            requestAnimationFrame(animateCounter);
                        } else {
                            target.innerText = targetValue;
                        }
                    }
                    
                    requestAnimationFrame(animateCounter);
                    observer.unobserve(target);
                }
            });
        }, {
            threshold: 0.1
        });
        
        counters.forEach(counter => {
            observer.observe(counter);
        });
    }
}

/**
 * Initialize SVG animations
 */
function initSvgAnimations() {
    // For SVG animations using styles
    const animatedSvgs = document.querySelectorAll('.animated-svg');
    
    animatedSvgs.forEach(svg => {
        try {
            // Apply initial animation class
            svg.classList.add('svg-animation');
        } catch (e) {
            console.log('SVG animation error:', e);
        }
    });
    
    // For path animations
    const animatedPaths = document.querySelectorAll('.path-animation');
    
    animatedPaths.forEach(path => {
        try {
            if (typeof path.getTotalLength === 'function') {
                const length = path.getTotalLength();
                path.style.strokeDasharray = length;
                path.style.strokeDashoffset = length;
                path.style.animation = 'dash 2s ease-in-out forwards';
            } else {
                path.style.animation = 'fadeIn 2s ease-in-out forwards';
            }
        } catch (e) {
            console.log('Animation error:', e);
            path.style.animation = 'fadeIn 2s ease-in-out forwards';
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations on page load
    initAnimations();
    
    // Header scroll effect
    initHeaderScrollEffect();
    
    // Mobile menu functionality
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navList = document.getElementById('navList');
    
    if (mobileMenuBtn && navList) {
        mobileMenuBtn.addEventListener('click', function() {
            navList.classList.toggle('active');
            // Update the icon based on menu state
            const icon = mobileMenuBtn.querySelector('svg');
            if (navList.classList.contains('active')) {
                feather.replace(icon, { 'name': 'x' });
            } else {
                feather.replace(icon, { 'name': 'menu' });
            }
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.main-nav') && navList.classList.contains('active')) {
                navList.classList.remove('active');
                feather.replace(mobileMenuBtn.querySelector('svg'), { 'name': 'menu' });
            }
        });
    }
    
    // Auto-dismiss messages after 5 seconds
    const messages = document.querySelectorAll('.message');
    
    if (messages.length > 0) {
        messages.forEach(message => {
            setTimeout(() => {
                message.style.opacity = '0';
                setTimeout(() => {
                    message.style.display = 'none';
                }, 300);
            }, 5000);
        });
    }
    
    // Initialize price formatting for Indian Rupees
    initRupeePriceFormatting();
    
    // Initialize animated counters
    initCounters();
    
    // Initialize SVG animations
    initSvgAnimations();
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            
            // Only handle actual anchor links, not toggles or tabs
            if (href !== '#' && href.startsWith('#')) {
                e.preventDefault();
                
                const targetElement = document.querySelector(this.getAttribute('href'));
                if (targetElement) {
                    // Close mobile menu if open
                    if (navList && navList.classList.contains('active')) {
                        navList.classList.remove('active');
                        feather.replace(mobileMenuBtn.querySelector('svg'), { 'name': 'menu' });
                    }
                    
                    // Scroll to element
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // Form validation enhancement
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const requiredInputs = form.querySelectorAll('input[required], textarea[required], select[required]');
        
        requiredInputs.forEach(input => {
            // Add visual feedback as user types
            input.addEventListener('input', function() {
                if (this.value.trim() === '') {
                    this.classList.add('is-invalid');
                    this.classList.remove('is-valid');
                } else {
                    this.classList.remove('is-invalid');
                    this.classList.add('is-valid');
                }
            });
            
            // Initial check for prefilled values
            if (input.value.trim() !== '') {
                input.classList.add('is-valid');
            }
        });
        
        // Email validation
        const emailInputs = form.querySelectorAll('input[type="email"]');
        emailInputs.forEach(email => {
            email.addEventListener('input', function() {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (email.value.trim() === '' || !emailRegex.test(email.value)) {
                    email.classList.add('is-invalid');
                    email.classList.remove('is-valid');
                } else {
                    email.classList.remove('is-invalid');
                    email.classList.add('is-valid');
                }
            });
        });
    });
    
    // Add current year to footer copyright
    const copyrightYear = document.querySelector('.footer-bottom p');
    if (copyrightYear) {
        const currentYear = new Date().getFullYear();
        copyrightYear.innerHTML = copyrightYear.innerHTML.replace('{year}', currentYear);
    }
    
    // Initialize any carousels or sliders if needed
    // This is a placeholder for future slider implementation
    
    // Back to top button functionality
    // First, let's create and append the button
    const backToTopBtn = document.createElement('button');
    backToTopBtn.innerHTML = '<i data-feather="arrow-up"></i>';
    backToTopBtn.className = 'back-to-top';
    backToTopBtn.style.position = 'fixed';
    backToTopBtn.style.bottom = '20px';
    backToTopBtn.style.right = '20px';
    backToTopBtn.style.display = 'none';
    backToTopBtn.style.backgroundColor = 'var(--primary)';
    backToTopBtn.style.color = 'white';
    backToTopBtn.style.border = 'none';
    backToTopBtn.style.borderRadius = '50%';
    backToTopBtn.style.width = '40px';
    backToTopBtn.style.height = '40px';
    backToTopBtn.style.cursor = 'pointer';
    backToTopBtn.style.boxShadow = 'var(--shadow-md)';
    backToTopBtn.style.zIndex = '99';
    backToTopBtn.style.transition = 'opacity 0.3s, transform 0.3s';
    
    document.body.appendChild(backToTopBtn);
    feather.replace();
    
    // Show/hide the button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = 'flex';
            backToTopBtn.style.alignItems = 'center';
            backToTopBtn.style.justifyContent = 'center';
            backToTopBtn.style.opacity = '1';
            backToTopBtn.style.transform = 'translateY(0)';
        } else {
            backToTopBtn.style.opacity = '0';
            backToTopBtn.style.transform = 'translateY(20px)';
        }
    });
    
    // Scroll to top when button is clicked
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    // Handle FAQ accordion if present
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        // Style for accordion effect
        if (question && answer) {
            answer.style.maxHeight = '0';
            answer.style.overflow = 'hidden';
            answer.style.transition = 'max-height 0.3s ease';
            answer.style.padding = '0';
            
            question.style.cursor = 'pointer';
            question.style.position = 'relative';
            
            // Add indicator
            const indicator = document.createElement('span');
            indicator.innerHTML = '+';
            indicator.style.position = 'absolute';
            indicator.style.right = '0';
            indicator.style.top = '0';
            indicator.style.fontSize = '1.5rem';
            indicator.style.color = 'var(--primary)';
            indicator.style.transition = 'transform 0.3s ease';
            question.appendChild(indicator);
            
            question.addEventListener('click', function() {
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        const otherAnswer = otherItem.querySelector('.faq-answer');
                        const otherIndicator = otherItem.querySelector('.faq-question span');
                        if (otherAnswer) {
                            otherAnswer.style.maxHeight = '0';
                            otherAnswer.style.padding = '0';
                        }
                        if (otherIndicator) {
                            otherIndicator.style.transform = 'rotate(0deg)';
                        }
                    }
                });
                
                if (answer.style.maxHeight === '0px' || answer.style.maxHeight === '') {
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    answer.style.padding = 'var(--spacing-md) 0 0 0';
                    indicator.style.transform = 'rotate(45deg)';
                } else {
                    answer.style.maxHeight = '0';
                    answer.style.padding = '0';
                    indicator.style.transform = 'rotate(0deg)';
                }
            });
        }
    });
    
    // Add animation to process steps
    const processSteps = document.querySelectorAll('.process-step');
    
    if (processSteps.length > 0) {
        // Create an Intersection Observer
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });
        
        // Setup initial styles and observe each step
        processSteps.forEach((step, index) => {
            step.style.opacity = '0';
            step.style.transform = 'translateY(20px)';
            step.style.transition = `opacity 0.4s ease ${index * 0.1}s, transform 0.4s ease ${index * 0.1}s`;
            observer.observe(step);
        });
    }
    
    // Handle tabbed content if present
    const tabButtons = document.querySelectorAll('[data-tab-target]');
    const tabContents = document.querySelectorAll('[data-tab-content]');
    
    if (tabButtons.length > 0 && tabContents.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const target = document.querySelector(button.dataset.tabTarget);
                
                // Hide all tab contents
                tabContents.forEach(content => {
                    content.classList.remove('active');
                    content.style.display = 'none';
                });
                
                // Deactivate all tab buttons
                tabButtons.forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Show the selected tab content
                if (target) {
                    target.classList.add('active');
                    target.style.display = 'block';
                    button.classList.add('active');
                }
            });
        });
        
        // Activate the first tab by default
        if (tabButtons[0]) {
            tabButtons[0].click();
        }
    }
});