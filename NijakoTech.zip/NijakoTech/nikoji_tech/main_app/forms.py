from django import forms
from .models import ContactMessage, ServiceRequest, RequirementSubmission


class ContactForm(forms.ModelForm):
    """Form for contact page"""
    
    class Meta:
        model = ContactMessage
        fields = ['name', 'email', 'phone', 'subject', 'message']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Your Email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Phone Number (optional)'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Subject'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Your Message', 'rows': 5}),
        }


class ServiceRequestForm(forms.ModelForm):
    """Form for service request page"""
    preferred_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        required=False
    )
    
    class Meta:
        model = ServiceRequest
        fields = ['name', 'email', 'phone', 'company', 'service_type', 
                 'priority', 'description', 'preferred_date']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Your Email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Phone Number'}),
            'company': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Company (optional)'}),
            'service_type': forms.Select(attrs={'class': 'form-control'}),
            'priority': forms.Select(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Describe your service request', 'rows': 5}),
        }


class RequirementSubmissionForm(forms.ModelForm):
    """Form for requirement gathering page"""
    
    class Meta:
        model = RequirementSubmission
        fields = ['name', 'email', 'phone', 'company', 'project_title', 
                 'project_description', 'timeline', 'budget_range', 'additional_info']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Name'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Your Email'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Phone Number'}),
            'company': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Your Company (optional)'}),
            'project_title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Project Title'}),
            'project_description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Describe your project requirements', 'rows': 5}),
            'timeline': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Expected timeline (e.g., 3 months, Q4 2023)'}),
            'budget_range': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Budget range (optional)'}),
            'additional_info': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Any additional information', 'rows': 3}),
        }
