from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import Service, Project, Testimonial
from .forms import ContactForm, ServiceRequestForm, RequirementSubmissionForm


def home(request):
    """Home page view"""
    services = Service.objects.filter(is_active=True)[:6]
    featured_projects = Project.objects.filter(is_featured=True)[:3]
    testimonials = Testimonial.objects.filter(is_active=True)[:3]
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            
            # Send email notification
            subject = f"New Contact Form Submission: {form.cleaned_data['subject']}"
            message = (
                f"Name: {form.cleaned_data['name']}\n"
                f"Email: {form.cleaned_data['email']}\n"
                f"Phone: {form.cleaned_data['phone']}\n\n"
                f"Message:\n{form.cleaned_data['message']}"
            )
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.DEFAULT_FROM_EMAIL],
                    fail_silently=False,
                )
            except Exception as e:
                # Log the error but don't stop the user from submitting
                print(f"Email sending failed: {str(e)}")
                
            messages.success(request, "Your message has been sent successfully! We'll get back to you soon.")
            return redirect('main_app:form_success')
    else:
        form = ContactForm()
    
    context = {
        'services': services,
        'featured_projects': featured_projects,
        'testimonials': testimonials,
        'form': form,
    }
    return render(request, 'main_app/home.html', context)


def automation(request):
    """Automation page view"""
    context = {
        'title': 'Automation Solutions',
        'description': 'Our comprehensive automation solutions for industrial applications.'
    }
    return render(request, 'main_app/automation.html', context)


def innovation(request):
    """Innovation page view"""
    context = {
        'title': 'Innovation',
        'subtitle': 'We Are Here to Match Your Expectations',
        'description': 'Discover our innovative approaches to industrial technology.'
    }
    return render(request, 'main_app/innovation.html', context)


def design_development(request):
    """Design & Development page view"""
    context = {
        'title': 'Design & Development',
        'subtitle': 'We Deliver What You Think',
        'description': 'Our design and development process for turning concepts into reality.'
    }
    return render(request, 'main_app/design_development.html', context)


def testing(request):
    """Testing page view"""
    context = {
        'title': 'Testing Services',
        'description': 'Comprehensive testing solutions including ICT, FCT, FPT, and ATE.'
    }
    return render(request, 'main_app/testing.html', context)


def service(request):
    """Service page view with service request form"""
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST)
        if form.is_valid():
            service_request = form.save()
            
            # Send email notification
            subject = f"New Service Request: {form.cleaned_data['service_type']}"
            message = (
                f"Name: {form.cleaned_data['name']}\n"
                f"Email: {form.cleaned_data['email']}\n"
                f"Phone: {form.cleaned_data['phone']}\n"
                f"Company: {form.cleaned_data['company']}\n"
                f"Service Type: {form.cleaned_data['service_type']}\n"
                f"Priority: {form.cleaned_data['priority']}\n"
                f"Preferred Date: {form.cleaned_data['preferred_date']}\n\n"
                f"Description:\n{form.cleaned_data['description']}"
            )
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.DEFAULT_FROM_EMAIL],
                    fail_silently=False,
                )
            except Exception as e:
                # Log the error but don't stop the user from submitting
                print(f"Email sending failed: {str(e)}")
                
            messages.success(request, "Your service request has been submitted successfully! Our team will contact you shortly.")
            return redirect('main_app:form_success')
    else:
        form = ServiceRequestForm()
    
    context = {
        'title': 'Repair & Maintenance Services',
        'description': 'Professional repair and maintenance services for industrial equipment.',
        'form': form,
    }
    return render(request, 'main_app/service.html', context)


def software_development(request):
    """Software Development page view with project form"""
    projects = Project.objects.filter(services_used__title__icontains='software')[:6]
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            
            # Send email notification
            subject = f"New Software Development Inquiry: {form.cleaned_data['subject']}"
            message = (
                f"Name: {form.cleaned_data['name']}\n"
                f"Email: {form.cleaned_data['email']}\n"
                f"Phone: {form.cleaned_data['phone']}\n\n"
                f"Message:\n{form.cleaned_data['message']}"
            )
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.DEFAULT_FROM_EMAIL],
                    fail_silently=False,
                )
            except Exception as e:
                # Log the error but don't stop the user from submitting
                print(f"Email sending failed: {str(e)}")
                
            messages.success(request, "Your software development inquiry has been sent successfully! We'll get back to you soon.")
            return redirect('main_app:form_success')
    else:
        form = ContactForm(initial={'subject': 'Software Development Inquiry'})
    
    context = {
        'title': 'Software Development',
        'description': 'Custom software solutions for industrial automation and control systems.',
        'projects': projects,
        'form': form,
    }
    return render(request, 'main_app/software_development.html', context)


def requirement_gathering(request):
    """Requirement Gathering page view with form"""
    if request.method == 'POST':
        form = RequirementSubmissionForm(request.POST)
        if form.is_valid():
            requirement = form.save()
            
            # Send email notification
            subject = f"New Project Requirements: {form.cleaned_data['project_title']}"
            message = (
                f"Name: {form.cleaned_data['name']}\n"
                f"Email: {form.cleaned_data['email']}\n"
                f"Phone: {form.cleaned_data['phone']}\n"
                f"Company: {form.cleaned_data['company']}\n"
                f"Project: {form.cleaned_data['project_title']}\n"
                f"Timeline: {form.cleaned_data['timeline']}\n"
                f"Budget: {form.cleaned_data['budget_range']}\n\n"
                f"Project Description:\n{form.cleaned_data['project_description']}\n\n"
                f"Additional Info:\n{form.cleaned_data['additional_info']}"
            )
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.DEFAULT_FROM_EMAIL],
                    fail_silently=False,
                )
            except Exception as e:
                # Log the error but don't stop the user from submitting
                print(f"Email sending failed: {str(e)}")
                
            messages.success(request, "Your project requirements have been submitted successfully! Our team will review and contact you shortly.")
            return redirect('main_app:form_success')
    else:
        form = RequirementSubmissionForm()
    
    context = {
        'title': 'Requirement Gathering',
        'description': 'Our detailed process for gathering and analyzing project requirements.',
        'form': form,
    }
    return render(request, 'main_app/requirement_gathering.html', context)


def smt_solution(request):
    """SMT Solution page view"""
    context = {
        'title': 'SMT Solutions',
        'description': 'Our comprehensive Electronic Manufacturing Services (EMS) and SMT solutions.'
    }
    return render(request, 'main_app/smt_solution.html', context)


def consultancy(request):
    """Consultancy page view"""
    testimonials = Testimonial.objects.filter(is_active=True)
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            
            # Send email notification
            subject = f"New Consultancy Inquiry: {form.cleaned_data['subject']}"
            message = (
                f"Name: {form.cleaned_data['name']}\n"
                f"Email: {form.cleaned_data['email']}\n"
                f"Phone: {form.cleaned_data['phone']}\n\n"
                f"Message:\n{form.cleaned_data['message']}"
            )
            try:
                send_mail(
                    subject,
                    message,
                    settings.DEFAULT_FROM_EMAIL,
                    [settings.DEFAULT_FROM_EMAIL],
                    fail_silently=False,
                )
            except Exception as e:
                # Log the error but don't stop the user from submitting
                print(f"Email sending failed: {str(e)}")
                
            messages.success(request, "Your consultancy inquiry has been sent successfully! We'll get back to you soon.")
            return redirect('main_app:form_success')
    else:
        form = ContactForm(initial={'subject': 'Consultancy Services Inquiry'})
    
    context = {
        'title': 'Consultancy Services',
        'description': 'Expert consultancy services for industrial automation and control systems.',
        'testimonials': testimonials,
        'form': form,
    }
    return render(request, 'main_app/consultancy.html', context)


def form_success(request):
    """Success page after form submission"""
    return render(request, 'main_app/form_success.html')


def portfolio(request):
    """Portfolio page view showing all projects"""
    projects = Project.objects.all().order_by('-completion_date')
    
    context = {
        'title': 'Our Portfolio',
        'description': 'Explore our portfolio of successful projects and implementations',
        'projects': projects,
    }
    return render(request, 'main_app/portfolio.html', context)


def portfolio_detail(request, project_id):
    """Detailed view of a single portfolio project"""
    project = get_object_or_404(Project, id=project_id)
    related_projects = Project.objects.filter(services_used__in=project.services_used.all()).exclude(id=project.id).distinct()[:3]
    
    context = {
        'title': project.title,
        'project': project,
        'related_projects': related_projects,
    }
    return render(request, 'main_app/portfolio_detail.html', context)


def case_studies(request):
    """Case studies page view"""
    # Featured case studies (using the Project model)
    case_studies = Project.objects.filter(is_featured=True).order_by('-completion_date')
    
    context = {
        'title': 'Case Studies',
        'description': 'Detailed analysis of our most impactful projects',
        'case_studies': case_studies,
    }
    return render(request, 'main_app/case_studies.html', context)


def case_study_detail(request, project_id):
    """Detailed view of a single case study"""
    project = get_object_or_404(Project, id=project_id)
    
    context = {
        'title': f'Case Study: {project.title}',
        'project': project,
    }
    return render(request, 'main_app/case_study_detail.html', context)


def team(request):
    """Team page view"""
    context = {
        'title': 'Our Team',
        'description': 'Meet the talented professionals behind Nikoji Technologies',
    }
    return render(request, 'main_app/team.html', context)


def careers(request):
    """Careers page view"""
    context = {
        'title': 'Careers',
        'description': 'Join our team of innovators and technology enthusiasts',
    }
    return render(request, 'main_app/careers.html', context)


def faq(request):
    """FAQ page view"""
    context = {
        'title': 'Frequently Asked Questions',
        'description': 'Find answers to commonly asked questions about our services and solutions',
    }
    return render(request, 'main_app/faq.html', context)
