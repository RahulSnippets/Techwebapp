from django.db import models
from django.utils import timezone


class Service(models.Model):
    """Model for company services"""
    title = models.CharField(max_length=100)
    description = models.TextField()
    icon_class = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class Project(models.Model):
    """Model for company projects/portfolio"""
    title = models.CharField(max_length=100)
    description = models.TextField()
    client = models.CharField(max_length=100)
    completion_date = models.DateField()
    image_url = models.URLField(blank=True, null=True)
    services_used = models.ManyToManyField(Service, related_name='projects')
    is_featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title
    
    class Meta:
        ordering = ['-completion_date']


class Testimonial(models.Model):
    """Model for client testimonials"""
    client_name = models.CharField(max_length=100)
    client_company = models.CharField(max_length=100)
    client_position = models.CharField(max_length=100)
    content = models.TextField()
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.client_name} - {self.client_company}"


class ContactMessage(models.Model):
    """Model for contact form submissions"""
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.subject}"
    
    class Meta:
        ordering = ['-created_at']


class ServiceRequest(models.Model):
    """Model for service request form submissions"""
    SERVICE_TYPES = (
        ('repair', 'Repair Service'),
        ('maintenance', 'Maintenance'),
        ('installation', 'Installation'),
        ('consultation', 'Consultation'),
        ('software', 'Software Development'),
        ('other', 'Other'),
    )
    
    PRIORITY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    )
    
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    company = models.CharField(max_length=100, blank=True)
    service_type = models.CharField(max_length=20, choices=SERVICE_TYPES)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    description = models.TextField()
    preferred_date = models.DateField(null=True, blank=True)
    is_processed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(null=True, blank=True)
    
    def mark_as_processed(self):
        self.is_processed = True
        self.processed_at = timezone.now()
        self.save()
    
    def __str__(self):
        return f"{self.name} - {self.service_type} ({self.priority})"
    
    class Meta:
        ordering = ['-created_at']


class RequirementSubmission(models.Model):
    """Model for requirement gathering form submissions"""
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    company = models.CharField(max_length=100, blank=True)
    project_title = models.CharField(max_length=200)
    project_description = models.TextField()
    timeline = models.CharField(max_length=100, blank=True)
    budget_range = models.CharField(max_length=100, blank=True)
    additional_info = models.TextField(blank=True)
    is_reviewed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.name} - {self.project_title}"
    
    class Meta:
        ordering = ['-created_at']
