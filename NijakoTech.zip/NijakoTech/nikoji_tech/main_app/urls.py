from django.urls import path
from . import views

app_name = 'main_app'

urlpatterns = [
    path('', views.home, name='home'),
    path('automation/', views.automation, name='automation'),
    path('innovation/', views.innovation, name='innovation'),
    path('design-development/', views.design_development, name='design_development'),
    path('testing/', views.testing, name='testing'),
    path('service/', views.service, name='service'),
    path('software-development/', views.software_development, name='software_development'),
    path('requirement-gathering/', views.requirement_gathering, name='requirement_gathering'),
    path('smt-solution/', views.smt_solution, name='smt_solution'),
    path('consultancy/', views.consultancy, name='consultancy'),
    path('form-success/', views.form_success, name='form_success'),
    
    # Portfolio pages
    path('portfolio/', views.portfolio, name='portfolio'),
    path('portfolio/<int:project_id>/', views.portfolio_detail, name='portfolio_detail'),
    path('case-studies/', views.case_studies, name='case_studies'),
    path('case-studies/<int:project_id>/', views.case_study_detail, name='case_study_detail'),
    path('team/', views.team, name='team'),
    path('careers/', views.careers, name='careers'),
    path('faq/', views.faq, name='faq'),
]
