from django.contrib import admin
from .models import (
    Service, Project, Testimonial, 
    ContactMessage, ServiceRequest, RequirementSubmission
)

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('title', 'is_active', 'created_at', 'updated_at')
    list_filter = ('is_active',)
    search_fields = ('title', 'description')

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'client', 'completion_date', 'is_featured')
    list_filter = ('is_featured', 'completion_date')
    search_fields = ('title', 'description', 'client')
    filter_horizontal = ('services_used',)

@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ('client_name', 'client_company', 'rating', 'is_active')
    list_filter = ('rating', 'is_active')
    search_fields = ('client_name', 'client_company', 'content')

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'created_at', 'is_read')
    list_filter = ('is_read', 'created_at')
    search_fields = ('name', 'email', 'subject', 'message')
    readonly_fields = ('name', 'email', 'phone', 'subject', 'message', 'created_at')
    
    def has_add_permission(self, request):
        return False
    
    def has_delete_permission(self, request, obj=None):
        # Prevent accidental deletion in admin panel
        # Can still be deleted via queryset actions if needed
        return request.user.is_superuser

@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    list_display = ('name', 'service_type', 'priority', 'created_at', 'is_processed')
    list_filter = ('service_type', 'priority', 'is_processed')
    search_fields = ('name', 'email', 'company', 'description')
    readonly_fields = ('name', 'email', 'phone', 'company', 'service_type', 
                      'priority', 'description', 'preferred_date', 'created_at')
    actions = ['mark_as_processed']
    
    def has_add_permission(self, request):
        return False
    
    def mark_as_processed(self, request, queryset):
        for request_obj in queryset:
            request_obj.mark_as_processed()
        self.message_user(request, f"{queryset.count()} service requests marked as processed")
    mark_as_processed.short_description = "Mark selected requests as processed"

@admin.register(RequirementSubmission)
class RequirementSubmissionAdmin(admin.ModelAdmin):
    list_display = ('name', 'project_title', 'created_at', 'is_reviewed')
    list_filter = ('is_reviewed', 'created_at')
    search_fields = ('name', 'email', 'company', 'project_title', 'project_description')
    readonly_fields = ('name', 'email', 'phone', 'company', 'project_title', 
                      'project_description', 'timeline', 'budget_range', 
                      'additional_info', 'created_at')
    
    def has_add_permission(self, request):
        return False
