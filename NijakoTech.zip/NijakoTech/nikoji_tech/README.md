# Nikoji Technologies Website

A professional website for Nikoji Technologies, a company in the Industrial Automation and EMS domain. Built with Django, HTML/CSS, and PostgreSQL.

## Features

- Multi-page website with responsive design
- Complete sections: Home, Automation, Innovation, Design & Development, Testing, etc.
- Interactive elements and animations
- Contact forms with database storage
- Requirement gathering and service request forms
- Admin panel for content management

## Setup Instructions

### Local Development Setup (VS Code)

1. **Clone the repository**
   ```
   git clone <repository-url>
   cd nikoji_tech
   ```

2. **Set up a virtual environment**
   ```
   python -m venv venv
   ```

   - On Windows:
     ```
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```
     source venv/bin/activate
     ```

3. **Install dependencies**
   ```
   pip install -r requirements.txt
   ```

4. **Configure environment variables**
   
   Create a `.env` file in the project root with the following variables:
   ```
   DJANGO_SECRET_KEY=your-secret-key-here
   DJANGO_DEBUG=True
   
   PGDATABASE=your_database_name
   PGUSER=your_database_user
   PGPASSWORD=your_database_password
   PGHOST=localhost
   PGPORT=5432
   
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_HOST_USER=your-email@gmail.com
   EMAIL_HOST_PASSWORD=your-app-password
   DEFAULT_FROM_EMAIL=noreply@nikojitechnologies.com
   ```

5. **Set up the PostgreSQL database**
   
   - Install PostgreSQL if not already installed
   - Create a database with the name specified in your `.env` file
   - Make sure the database user has appropriate permissions

6. **Run migrations**
   ```
   python manage.py makemigrations
   python manage.py migrate
   ```

7. **Create a superuser**
   ```
   python manage.py createsuperuser
   ```

8. **Run the development server**
   ```
   python manage.py runserver
   ```

9. **Access the website**
   - Main site: http://localhost:8000/
   - Admin panel: http://localhost:8000/admin/

### Deployment to cPanel

1. **Prepare your project**
   
   - Make sure `DEBUG=False` in your `.env` file
   - Update `ALLOWED_HOSTS` in settings.py to include your domain
   - Collect static files:
     ```
     python manage.py collectstatic
     ```

2. **Create a cPanel account**
   
   - Log in to your cPanel account
   - Navigate to the "Software" section and find "Setup Python App"

3. **Configure Python application**
   
   - Choose Python version (3.8 or higher)
   - Set the application root to your project directory
   - Set the application URL to your domain
   - Set the application startup file to `passenger_wsgi.py`
   - Save the configuration

4. **Create passenger_wsgi.py**
   
   Create a file named `passenger_wsgi.py` in your project root:
   ```python
   import os
   import sys
   
   from django.core.wsgi import get_wsgi_application
   
   # Add the project directory to the Python path
   sys.path.insert(0, os.path.dirname(__file__))
   
   # Set environment variable to use production settings
   os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nikoji_tech.settings')
   
   # Create the WSGI application
   application = get_wsgi_application()
   ```

5. **Set up the database**
   
   - Create a MySQL or PostgreSQL database in cPanel
   - Update your `.env` file with the database credentials
   - Run migrations:
     ```
     python manage.py migrate
     ```

6. **Upload project files**
   
   - Use FTP or File Manager to upload your project files to the server
   - Make sure to include the `.env` file, but keep it secure
   - Ensure proper permissions:
     ```
     chmod 750 ~/your_project_directory
     chmod 640 ~/your_project_directory/*.py
     chmod 750 ~/your_project_directory/manage.py
     ```

7. **Configure HTTPS**
   
   - Use "SSL/TLS Status" in cPanel to secure your site with HTTPS
   - Make sure your site enforces HTTPS by setting `SECURE_SSL_REDIRECT = True` in settings.py

8. **Restart the application**
   
   - Use the "Setup Python App" interface to restart your application

## Project Structure

- `nikoji_tech/` - Django project folder
  - `main_app/` - Main Django application
    - `static/` - Static files (CSS, JS, images)
    - `templates/` - HTML templates
    - `migrations/` - Database migrations
    - `models.py` - Database models
    - `views.py` - View functions
    - `urls.py` - URL routing
  - `postgresql_files/` - PostgreSQL database files and backups
  - `media/` - User-uploaded content
  - `nikoji_tech/` - Project settings

## Maintenance

- **Database Backups**
  ```
  python manage.py dumpdata > postgresql_files/backup_$(date +%Y%m%d).json
  ```

- **Update Dependencies**
  ```
  pip install -r requirements.txt --upgrade
  python manage.py migrate
  ```

## Contact

For any questions or support, contact:
- support@nikojitechnologies.com