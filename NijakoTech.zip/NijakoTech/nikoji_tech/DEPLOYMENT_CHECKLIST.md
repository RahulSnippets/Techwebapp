# Deployment Checklist for Nikoji Technologies Website

Use this checklist to ensure you've included all necessary files when deploying the website to cPanel or any other hosting environment.

## Files to Include

### Core Django Files
- [x] `manage.py`
- [x] `passenger_wsgi.py`
- [x] `.htaccess`
- [x] `requirements.txt`

### Django Application Directory Structure
- [x] `nikoji_tech/` (project directory)
  - [x] `__init__.py`
  - [x] `asgi.py`
  - [x] `settings.py`
  - [x] `urls.py`
  - [x] `wsgi.py`

- [x] `main_app/` (application directory)
  - [x] `__init__.py`
  - [x] `admin.py`
  - [x] `apps.py`
  - [x] `forms.py`
  - [x] `models.py`
  - [x] `urls.py`
  - [x] `views.py`
  - [x] `migrations/` (including all migration files)
    - [x] `__init__.py`
    - [x] All numbered migration files (e.g., `0001_initial.py`)
  - [x] `templatetags/`
    - [x] `__init__.py`
    - [x] `custom_filters.py`

### Templates and Static Files
- [x] `main_app/templates/` (all template directories and files)
- [x] `main_app/static/` (all static files)
  - [x] `css/`
  - [x] `js/`
  - [x] `images/`
  - [x] `fonts/` (if used)

### Documentation (optional but recommended)
- [x] `README.md`
- [x] `DEPLOYMENT.md`
- [x] `VS_CODE_SETUP.md`
- [x] `DEPLOYMENT_CHECKLIST.md` (this file)

## Files to Create on the Server

- [ ] `.env` (based on `.env.example`, with production values)

## Files/Directories to Exclude

- [ ] `__pycache__/` directories
- [ ] `.pyc` files
- [ ] `venv/` or any virtual environment directory
- [ ] `.git/` directory (if using Git)
- [ ] `.vscode/` directory (VS Code settings)
- [ ] Local database files (e.g., `.sqlite3` files if used)
- [ ] Temporary files (`.tmp`, `.bak`, `.swp`)
- [ ] System files (`.DS_Store`, `Thumbs.db`)

## Pre-Deployment Configuration

Before deploying, make sure to update these settings:

1. In `settings.py`:
   - [ ] Set `DEBUG = False`
   - [ ] Update `ALLOWED_HOSTS` with your production domain
   - [ ] Configure `STATIC_ROOT` and `MEDIA_ROOT` paths
   - [ ] Update email settings (if using email features)
   - [ ] Update database settings (or use environment variables)

2. In `.env` file (create on server):
   - [ ] Set secure `SECRET_KEY`
   - [ ] Configure `DATABASE_URL` with production database details
   - [ ] Add any other environment-specific variables

## Post-Deployment Steps

After uploading all files to the server:

1. [ ] Install requirements: `pip install -r requirements.txt`
2. [ ] Run migrations: `python manage.py migrate`
3. [ ] Collect static files: `python manage.py collectstatic --no-input`
4. [ ] Create superuser: `python manage.py createsuperuser`
5. [ ] Set proper file permissions
6. [ ] Test all features

## Recommended cPanel Settings

- [ ] Set up a Python application (Python Version 3.10+)
- [ ] Configure PostgreSQL database
- [ ] Set up SSL certificate
- [ ] Configure email settings (if applicable)
- [ ] Set up backup schedule

---

This checklist helps ensure a smooth deployment process. Refer to `DEPLOYMENT.md` for detailed instructions on each step.