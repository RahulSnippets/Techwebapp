--
-- PostgreSQL database dump
--

-- Dumped from database version 15.3
-- Dumped by pg_dump version 15.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA public;

-- Sample data only for demonstration purposes
-- This is not a complete database dump

-- Sample schema for main_app_service
CREATE TABLE IF NOT EXISTS public.main_app_service (
    id bigint NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    icon_class character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);

-- Sample schema for main_app_project
CREATE TABLE IF NOT EXISTS public.main_app_project (
    id bigint NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    client character varying(100) NOT NULL,
    completion_date date NOT NULL,
    image_url character varying(200),
    is_featured boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);

-- Sample schema for main_app_testimonial
CREATE TABLE IF NOT EXISTS public.main_app_testimonial (
    id bigint NOT NULL,
    client_name character varying(100) NOT NULL,
    client_company character varying(100) NOT NULL,
    client_position character varying(100) NOT NULL,
    content text NOT NULL,
    rating integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);

-- End of sample backup file