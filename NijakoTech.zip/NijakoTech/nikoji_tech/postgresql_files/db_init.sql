-- Nikoji Technologies Database Initialization Script

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create sequences for IDs
CREATE SEQUENCE IF NOT EXISTS service_id_seq;
CREATE SEQUENCE IF NOT EXISTS project_id_seq;
CREATE SEQUENCE IF NOT EXISTS testimonial_id_seq;
CREATE SEQUENCE IF NOT EXISTS contact_message_id_seq;
CREATE SEQUENCE IF NOT EXISTS service_request_id_seq;
CREATE SEQUENCE IF NOT EXISTS requirement_submission_id_seq;

-- Create initial admin user function
CREATE OR REPLACE FUNCTION create_initial_admin()
RETURNS void AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM django_content_type
        WHERE app_label = 'auth'
        AND model = 'user'
    ) THEN
        RETURN;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM auth_user 
        WHERE username = 'admin'
    ) THEN
        INSERT INTO auth_user (
            password, 
            is_superuser, 
            username, 
            first_name, 
            last_name, 
            email, 
            is_staff, 
            is_active, 
            date_joined
        ) VALUES (
            'pbkdf2_sha256$260000$nikojiAdminPasswordHash$nikojiAdminPasswordHash', -- Replace with actual hashed password
            TRUE, 
            'admin', 
            'Nikoji', 
            'Admin', 
            'admin@nikojitechnologies.com', 
            TRUE, 
            TRUE, 
            NOW()
        );
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Create sample data function
CREATE OR REPLACE FUNCTION create_sample_services()
RETURNS void AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.tables
        WHERE table_name = 'main_app_service'
    ) THEN
        RETURN;
    END IF;

    IF NOT EXISTS (
        SELECT 1 
        FROM main_app_service 
        WHERE title = 'PLC Programming'
    ) THEN
        INSERT INTO main_app_service (
            title, 
            description, 
            icon_class, 
            is_active, 
            created_at, 
            updated_at
        ) VALUES
        ('PLC Programming', 'Expert PLC programming and integration services for industrial automation.', 'server', TRUE, NOW(), NOW()),
        ('SCADA Systems', 'Design and implementation of SCADA systems for real-time monitoring and control.', 'monitor', TRUE, NOW(), NOW()),
        ('HMI Design', 'User-friendly HMI design for efficient operator interaction with systems.', 'layout', TRUE, NOW(), NOW()),
        ('VFD Installation', 'Variable Frequency Drive installation and configuration for motor control.', 'activity', TRUE, NOW(), NOW()),
        ('Industrial IoT', 'Internet of Things solutions for industrial applications and monitoring.', 'cpu', TRUE, NOW(), NOW());
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Add database comments and documentation
COMMENT ON DATABASE current_database() IS 'Nikoji Technologies main database for company website and applications';

-- Create database indexes
CREATE INDEX IF NOT EXISTS idx_service_active ON main_app_service(is_active);
CREATE INDEX IF NOT EXISTS idx_project_featured ON main_app_project(is_featured);
CREATE INDEX IF NOT EXISTS idx_testimonial_active ON main_app_testimonial(is_active);
CREATE INDEX IF NOT EXISTS idx_contact_read ON main_app_contactmessage(is_read);
CREATE INDEX IF NOT EXISTS idx_service_request_processed ON main_app_servicerequest(is_processed);

-- Add maintenance triggers
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger function
CREATE OR REPLACE FUNCTION create_updated_at_trigger(table_name text)
RETURNS void AS $$
DECLARE
    trigger_name text;
BEGIN
    trigger_name := table_name || '_update_timestamp';
    
    EXECUTE format('
        DROP TRIGGER IF EXISTS %I ON %I;
        CREATE TRIGGER %I
        BEFORE UPDATE ON %I
        FOR EACH ROW
        EXECUTE FUNCTION update_timestamp();
    ', trigger_name, table_name, trigger_name, table_name);
END;
$$ LANGUAGE plpgsql;

-- Usage notes
COMMENT ON FUNCTION create_updated_at_trigger IS 'Creates a trigger to automatically update the updated_at timestamp on any table';
COMMENT ON FUNCTION update_timestamp IS 'Updates the updated_at timestamp to the current time';
COMMENT ON FUNCTION create_initial_admin IS 'Creates an initial admin user if one does not exist';
COMMENT ON FUNCTION create_sample_services IS 'Creates sample service records if none exist';

-- End of initialization script