# PostgreSQL Database Files for Nikoji Technologies

This directory contains PostgreSQL database files, scripts, and documentation for the Nikoji Technologies website.

## Contents

- `backup_script.sh`: Automated script for backing up the database
- `db_init.sql`: Database initialization script for setting up the database
- `backups/`: Directory containing database backups (automatically created)
- `schema_documentation.md`: Documentation of database schema

## Database Schema

The Nikoji Technologies database consists of the following main tables:

1. **Service** - Company services offered
2. **Project** - Portfolio of completed projects
3. **Testimonial** - Client testimonials and reviews
4. **ContactMessage** - Contact form submissions
5. **ServiceRequest** - Service request form submissions
6. **RequirementSubmission** - Project requirement gathering form submissions

## Backup Instructions

To manually backup the database:

1. Make sure you have PostgreSQL client tools installed
2. Run the backup script: `bash backup_script.sh`
3. Backups will be stored in the `backups/` directory

Automatic backups are configured to run daily via cron job.

## Restore Instructions

To restore a database from backup:

```bash
# Assuming environment variables are set or sourced from .env
gunzip -c backups/nikoji_db_backup_YYYYMMDD_HHMMSS.sql.gz | psql -h $PGHOST -p $PGPORT -U $PGUSER -d $PGDATABASE
```

## Maintenance Tasks

### Database Optimization

Periodically run the following commands to optimize database performance:

```sql
-- Analyze and update statistics
ANALYZE VERBOSE;

-- Vacuum to clean up deleted records
VACUUM FULL;

-- Reindex tables
REINDEX DATABASE nikoji_db;
```

### Creating New Migrations

When adding new models or changing existing ones:

1. Make changes to `models.py`
2. Generate migrations: `python manage.py makemigrations`
3. Apply migrations: `python manage.py migrate`
4. Update this documentation if needed

## Troubleshooting

Common issues and solutions:

- **Connection refused**: Check if PostgreSQL is running and credentials are correct
- **Permission denied**: Verify user permissions for the database
- **Relation does not exist**: Make sure migrations have been applied