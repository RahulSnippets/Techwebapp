# Nikoji Technologies Database Schema Documentation

## Overview

This document provides detailed information about the database schema for the Nikoji Technologies website. The database is built using PostgreSQL and Django's ORM.

## Tables

### Service

Stores information about the services offered by Nikoji Technologies.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| title | Varchar(100) | Service name |
| description | Text | Detailed description |
| icon_class | Varchar(50) | CSS icon class |
| is_active | Boolean | Service visibility status |
| created_at | Timestamp | Creation date |
| updated_at | Timestamp | Last update date |

### Project

Contains information about projects completed by Nikoji Technologies.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| title | Varchar(100) | Project title |
| description | Text | Project description |
| client | Varchar(100) | Client name |
| completion_date | Date | Project completion date |
| image_url | Varchar(200) | Project image URL |
| is_featured | Boolean | Featured on homepage |
| created_at | Timestamp | Creation date |
| updated_at | Timestamp | Last update date |

**Relationships:**
- Many-to-Many with Service (services_used)

### Testimonial

Stores client testimonials and reviews.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| client_name | Varchar(100) | Client name |
| client_company | Varchar(100) | Client's company |
| client_position | Varchar(100) | Client's position |
| content | Text | Testimonial content |
| rating | Integer | Rating (1-5) |
| is_active | Boolean | Testimonial visibility |
| created_at | Timestamp | Creation date |

### ContactMessage

Stores messages submitted through the contact form.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| name | Varchar(100) | Sender name |
| email | Varchar(254) | Sender email |
| phone | Varchar(20) | Sender phone (optional) |
| subject | Varchar(200) | Message subject |
| message | Text | Message content |
| is_read | Boolean | Read status |
| created_at | Timestamp | Submission date |

### ServiceRequest

Stores service requests submitted by clients.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| name | Varchar(100) | Client name |
| email | Varchar(254) | Client email |
| phone | Varchar(20) | Client phone |
| company | Varchar(100) | Client company (optional) |
| service_type | Varchar(20) | Type of service requested |
| priority | Varchar(10) | Request priority |
| description | Text | Request details |
| preferred_date | Date | Preferred service date |
| is_processed | Boolean | Processing status |
| created_at | Timestamp | Submission date |
| processed_at | Timestamp | Processing date |

### RequirementSubmission

Stores project requirement submissions.

| Column | Type | Description |
|--------|------|-------------|
| id | BigInt | Primary key |
| name | Varchar(100) | Client name |
| email | Varchar(254) | Client email |
| phone | Varchar(20) | Client phone |
| company | Varchar(100) | Client company (optional) |
| project_title | Varchar(200) | Project title |
| project_description | Text | Project requirements |
| timeline | Varchar(100) | Expected timeline |
| budget_range | Varchar(100) | Budget range |
| additional_info | Text | Additional information |
| is_reviewed | Boolean | Review status |
| created_at | Timestamp | Submission date |

## Indexes

| Table | Index Name | Columns | Description |
|-------|------------|---------|-------------|
| Service | idx_service_active | is_active | Optimize queries filtering by active status |
| Project | idx_project_featured | is_featured | Optimize featured project queries |
| Testimonial | idx_testimonial_active | is_active | Optimize queries filtering by active status |
| ContactMessage | idx_contact_read | is_read | Optimize queries filtering by read status |
| ServiceRequest | idx_service_request_processed | is_processed | Optimize queries filtering by processed status |

## Database Triggers

| Trigger | Table | Description |
|---------|-------|-------------|
| service_update_timestamp | Service | Updates the updated_at field |
| project_update_timestamp | Project | Updates the updated_at field |
| service_request_update_timestamp | ServiceRequest | Updates the updated_at field |

## Backup and Restore

Database backups are stored in the `backups/` directory with the naming convention `nikoji_db_backup_YYYYMMDD_HHMMSS.sql.gz`.

### Backup Command
```bash
pg_dump -h $PGHOST -p $PGPORT -U $PGUSER -d $PGDATABASE -F p > backup_file.sql
```

### Restore Command
```bash
psql -h $PGHOST -p $PGPORT -U $PGUSER -d $PGDATABASE < backup_file.sql
```