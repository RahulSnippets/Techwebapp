#!/bin/bash
# PostgreSQL Database Backup Script for Nikoji Technologies

# Configuration
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="$(dirname "$0")/backups"
BACKUP_FILE="${BACKUP_DIR}/nikoji_db_backup_${TIMESTAMP}.sql"

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Get database credentials from environment variables or .env file
source "$(dirname "$0")/../.env"

# Export database
echo "Creating database backup: ${BACKUP_FILE}"
PGPASSWORD=$PGPASSWORD pg_dump -h $PGHOST -p $PGPORT -U $PGUSER -d $PGDATABASE -F p > "$BACKUP_FILE"

# Compress the backup
gzip "$BACKUP_FILE"

echo "Database backup completed: ${BACKUP_FILE}.gz"

# Delete backups older than 30 days
find "$BACKUP_DIR" -name "nikoji_db_backup_*.sql.gz" -type f -mtime +30 -delete

echo "Old backups cleaned up"
echo "Backup process completed successfully!"